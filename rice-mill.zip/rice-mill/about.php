<!DOCTYPE html>
<html lang="zxx">
<head>
    
    <meta charset="utf-8">
 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sri Anandha Lakshmi Modern Rice Mill</title>
    <meta name="description" content="Sri Anandha Lakshmi Modern Rice Mill">
    <meta name="keywords" content="Sri Anandha Lakshmi Modern Rice Mill">
	

	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
	
	
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.theme.default.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/magnific-popup.css">
	

	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
    <script type="text/javascript" src="js/vendor/modernizr.min.js"></script>

</head>

<body>

	
	<div class="animationload">
		<div class="loader"></div>
	</div>
	

	<a href="#0" class="cd-top cd-is-visible cd-fade-out">Top</a>

	
    <?php include("header.php") ?>
 
	
	<div class="section banner-page about">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="title-page">Company Profile</div>
					<ol class="breadcrumb">
						<li><a href="index.html">About Us</a></li>
						<li class="active">Company Profile</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
	 
	
	<div class="section feature overlap">
		<div class="container">
			<div class="row">
				
				<div class="col-sm-6 col-md-6">
					
						
							<img src="images/about.jpg" alt="Company History">
					
				</div>
				<div class="col-sm-6 col-md-6">
					<h3>About</h3>
					<p align="justify">We started our business as rice retail and wholesales merchandise in 1995
and later expanded our business in paddy wholesale with a vision of establishing 
state-of-art modern rice mill. At 2000 the visionary S.Senthilkumar and S.Venkatachalam 
founded Sri Anandha Lakshmi  Modern rice mill with a mission of "Providing Good quality Rice to our 
quality customers".Two decades of experience in the field of rice milling industry makes us to ensure quality
 in all stages from procurement of paddy, processing and packing.</p> 
 <h3>Our Products</h3>
 <ol>
            <li>VVS IR 20</li>
            <li>Idly Rice</li>
            <li>Idly Kurunai</li>
            <li>Ponni kurunai</li>
            <li>kuralarasan ADT 36(old)</li>
            <li>Biriyani Siraka Sambaa Rice</li>
			
         </ol>
				</div>

				<div class="clearfix"></div>
				
			</div>
		</div>
	</div>
	
	
	 
	<?php include("footer.php") ?>
		
</body>
</html>