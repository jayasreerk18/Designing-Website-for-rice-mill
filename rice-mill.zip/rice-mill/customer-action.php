<?php
session_start();

require_once 'connect.php';


$username=$_POST['username']; 
$password=$_POST['password']; 


$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

$sql="SELECT * FROM customer WHERE username='$username' and password='$password'";
$result=mysql_query($sql);


$count=mysql_num_rows($result);


if($count==1){
	
	$_SESSION['login'] = true;
    $_SESSION['username'] = $username;



header("location:customer-dashboard.php");
}
else {
echo "Wrong Username or Password";
header('Refresh: 3; URL = customer-login.php');
}
ob_end_flush();
?>
