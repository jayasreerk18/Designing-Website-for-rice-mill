<div class="header">
    	
		<div class="topbar">
			<div class="container">
				<div class="row">
					<div class="col-sm-5 col-md-6">
						<div class="topbar-left">
							<div class="welcome-text">
							Welcome to Sri Anandha Lakshmi Modern Rice Mill
							</div>
						</div>
					</div>
					<div class="col-sm-7 col-md-6">
						<div class="topbar-right">
						
							<ul class="topbar-sosmed">
							<li>
								<a href="#"><i class="fa fa-facebook"></i></a>
							</li>
							<li>
								<a href="#"><i class="fa fa-twitter"></i></a>
							</li>
							<li>
								<a href="#"><i class="fa fa-instagram"></i></a>
							</li>
							<li>
								<a href="#"><i class="fa fa-pinterest"></i></a>
							</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>

		
		<div class="topbar-logo">
			<div class="container">
				

				<div class="contact-info">
					
					<div class="box-icon-1">
						
					</div>
					
					<div class="box-icon-1">
						
						
					</div>
					
					<a class="btn btn-cta pull-right">CUSTOMER PAGE</a>

				</div>
			</div>
		</div>

		
		<div class="navbar navbar-main">
		
			<div class="container container-nav">
				<div class="rowe">
						
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						
					</div>

					<a class="navbar-brand" href="index.html">
						<img src="images/logo.png" alt="" />
					</a>

					<nav class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-left">
							<li class="dropdown">
							  <a href="customer-dashboard.php" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">HOME</a>
							</li>
							
							<li class="dropdown">
							  <a href="buy-prodcts.php" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">BUY PRODUCTS</a>
							</li>
							<li class="dropdown">
							  <a href="myorder-list.php" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">MY ORDER LIST</a>
							</li>
							<li class="dropdown">
							  <a href="logout.php" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">LOGOUT</a>
							</li>
							
						</ul>

					</nav>
						
				</div>
			</div>
	    </div>

    </div>