<div class="footer">
<div class="container">
				<div class="row">
				
						</div>
					<div class="col-sm-12 col-md-12">

							<p class="center">Address: 55, Hospital Rd, Nggo Colony, Sivagiri, Tamil Nadu 638109.</p>
</div>
		
		<div class="fcopy">
			<div class="container">
				<div class="row">
				
						</div>
					<div class="col-sm-12 col-md-12">
						<p class="ftex">&copy; 2022 Sri Anandha Lakshmi Modern Rice Mill - All Rights Reserved</p> 
					</div>
				</div>
			</div>
		</div>
		
	</div>
	
	
	<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
	<script type="text/javascript" src="js/vendor/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/vendor/jquery.superslides.js"></script>
	<script type="text/javascript" src="js/vendor/owl.carousel.js"></script>
	<script type="text/javascript" src="js/vendor/bootstrap-hover-dropdown.min.js"></script>
	<script type="text/javascript" src="js/vendor/jquery.magnific-popup.min.js"></script>
	<script type="text/javascript" src="js/vendor/easings.js"></script>
	<script type="text/javascript" src="js/vendor/isotope.pkgd.min.js"></script>

	
	<script type="text/javascript" src="js/vendor/validator.min.js"></script>
	<script type="text/javascript" src="js/vendor/form-scripts.js"></script>
	
	<script type='text/javascript' src='https://maps.google.com/maps/api/js?sensor=false&amp;ver=4.1.5'></script>

	<script type="text/javascript" src="js/script.js"></script>