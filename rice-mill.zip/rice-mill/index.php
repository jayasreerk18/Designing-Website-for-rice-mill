<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sri Anandha Lakshmi Modern Rice Mill</title>
    <meta name="description" content="Sri Anandha Lakshmi Modern Rice Mill">
    <meta name="keywords" content="Sri Anandha Lakshmi Modern Rice Mill">
	
	
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
	
	
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/owl.theme.default.min.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/magnific-popup.css">
	
	
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
    <script type="text/javascript" src="js/vendor/modernizr.min.js"></script>

</head>

<body>

	
	<div class="animationload">
		<div class="loader"></div>
	</div>
	
	
	<a href="#0" class="cd-top cd-is-visible cd-fade-out">Top</a>

	
    <?php include("header.php") ?>
 

	<div id="slides" class="section banner">
		<ul class="slides-container">
			<li>
				<img src="images/slide-1.jpg" alt="">
			</li>
			<li>
				<img src="images/slide-2.jpg" alt="">
			</li>
			
			
		</ul>

		<nav class="slides-navigation">
			<div class="container">
				<a href="#" class="next">
					<i class="fa fa-chevron-right"></i>
				</a>
				<a href="#" class="prev">
					<i class="fa fa-chevron-left"></i>
				</a>
	      	</div>
	    </nav>
		
	</div>

	
	<div class="section feature overlap">
		<div class="container">

			<div class="row">
				
				<div class="col-sm-4 col-md-4">
				
					<div class="box-icon-2">
						<div class="icon">
							<div class="fa fa-star-o"></div>
						</div>
						<div class="body-content">
							<div class="heading">Rice Procurement</div>
							The first and most critical step towards total quality management is procurement of rice.
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-4">
				
					<div class="box-icon-2">
						<div class="icon">
							<div class="fa fa-umbrella"></div>
						</div>
						<div class="body-content">
							<div class="heading">Technology Standards</div>
							The company procures the best quality of paddy and processes it using state-of-the-art technology.
						</div>
					</div>
				</div>
				<div class="col-sm-4 col-md-4">
					
					<div class="box-icon-2">
						<div class="icon">
							<div class="fa fa-users"></div>
						</div>
						<div class="body-content">
							<div class="heading">Quality Standards</div>
							All the rice undergoes stringent quality tests before they are shipped to our esteemed customers. 
						</div>
					</div>
				</div>
				
			</div>

			<div class="row">
				<div class="col-sm-12 col-md-12">
					<h2 class="section-heading">
						ABOUT US
					</h2>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-5 col-md-5">
					<div class="jumbo-heading">
						<h2>About Us</h2>
						<span class="fa fa-paper-plane-o"></span>
					</div>
				</div>
				<div class="col-sm-7 col-md-7">
					<p class="lead" align="justify">We started our business as rice retail and wholesales merchandise in 1995
and later expanded our business in paddy wholesale with a vision of establishing 
state-of-art modern rice mill. At 2000 the visionary S.Senthilkumar and S.Venkatachalam 
founded Sri Anandha Lakshmi  Modern rice mill with a mission of "Providing Good quality Rice to our 
quality customers".Two decades of experience in the field of rice milling industry makes us to ensure quality
 in all stages from procurement of paddy, processing and packing.</p> 
				</div>

			</div>

		</div>
	</div>
	 <?php include("footer.php") ?>
	
	 
	
	

		
</body>
</html>